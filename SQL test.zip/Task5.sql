-- Task 5
select * from orders
where item LIKE '%ea%'or item like 'key%'
